#DocLab package

##A simple php laravel doc package

