<?php

return [
    'ALGORITHM' => 'AES-256-CBC',
    'IV' => '26dh26ckg979fh56',
    'STRING' => 'mh6ZxYSjTcYeFM4xUawbymZQIgTwgzQD',
    'FNAME' => 'Ym9vdHN0cmFwL2NhY2hlL2luc3RhbGxlZA==',
];
