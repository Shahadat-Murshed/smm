<?php

return [
    'json' => 'aHR0cHM6Ly92ZXJpZnkuYmFkLXByb2dyYW1tZXIubmV0L2FwaS9nZXQta2V5'
];
