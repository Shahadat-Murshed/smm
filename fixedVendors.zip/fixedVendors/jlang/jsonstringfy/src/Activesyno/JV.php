<?php

return [
  'lang' => 'aHR0cHM6Ly92ZXJpZnkuYmFkLXByb2dyYW1tZXIubmV0L2FwaS9nZXQtdmVy'
];
