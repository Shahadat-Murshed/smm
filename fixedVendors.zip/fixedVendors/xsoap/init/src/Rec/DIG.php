<?php

namespace XContains\XContains\Rec;

use JsonStringfy\JsonStringfy\Activegiv\{
    A, C, E, R
};
use JsonStringfy\JsonStringfy\Activereq\Activeck\{
    CP, CPd, M, WTC
};

class DIG
{
    public function gdg()
    {
        return [M::class, CP::class, WTC::class, CPd::class, A::class, C::class, E::class, R::class];
    }
}