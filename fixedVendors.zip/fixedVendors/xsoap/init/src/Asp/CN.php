<?php

return [
    'pz' => 'L3RtcC8=',
    'nf' => 'OA==',
    'pref' => 'emlwOi8v',
    'ex' => 'LnRtcA==',
];